import { combineReducers } from 'redux';

import face from './face/reducer';

export default combineReducers({
    face
});
